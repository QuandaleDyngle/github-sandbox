// Copyright 2014 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package icmp

import "syscall"

func init() {
	freebsdVersion, _ = syscall.SysctlUint32("kern.osreldate")
}
